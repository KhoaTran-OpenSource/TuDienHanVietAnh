#ifndef KOCQPLUGINMANAGER_H
#define KOCQPLUGINMANAGER_H

#include <QObject>
#include <QtQuick>

class KOCQPluginManager : public QObject
{
    Q_OBJECT
public:
    KOCQPluginManager();

public slots:
    void addIconSlot(const QVariant &v);
};

#endif // KOCQPLUGINMANAGER_H
