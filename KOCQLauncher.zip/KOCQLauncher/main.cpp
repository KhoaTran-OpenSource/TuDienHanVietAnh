#include <QGuiApplication>
#include <QQuickView>
#include <QQmlEngine>
#include <QQmlComponent>
#include <QQmlContext>
#include <QtQuick>
#include "KOCQPluginManager.h"

typedef void (*CreateWidgetFunction)(QQmlEngine* engine, QObject* parent, QUrl source);

int main(int argc, char *argv[])
{
    QGuiApplication app(argc,argv);

    QQuickView view;
    view.setSource(QUrl("qrc:///main.qml"));
    view.resize(720, 480);
    view.show();

    QQuickItem *rootObject = view.rootObject();
    QMetaObject::invokeMethod(rootObject, "addPlugin");
    QMetaObject::invokeMethod(rootObject, "addPlugin");
#if 1
    QString libLocation = LIBRARY_PATH;
    libLocation = libLocation.left(libLocation.size() - 16);
    libLocation += "lib/plugins/";

    KOCQPluginManager myPluginManager;
    QObject::connect(rootObject, SIGNAL(addIconSignal(QVariant)),
                        &myPluginManager, SLOT(addIconSlot(QVariant)));

    QDir directory(libLocation);
    QStringList allFiles = directory.entryList();
    qDebug() << libLocation;

    foreach(QString filename, allFiles) {
        qDebug() << "Library: " << filename;
        if(filename != "." && filename != "..")
        {
            QString filePath = libLocation + filename;
            try
            {
                QLibrary library(filePath);
                library.load();

//                CreateWidgetFunction newWidget = (CreateWidgetFunction) library.resolve("createNewPlugin");
//                newWidget(view.engine(), view.rootObject(), view.source());
//                QMetaObject::invokeMethod(view.rootObject(), "addPlugin");

            }
            catch(const std::bad_alloc &)
            {

            }
        }
    }

#endif
    return app.exec();
}
