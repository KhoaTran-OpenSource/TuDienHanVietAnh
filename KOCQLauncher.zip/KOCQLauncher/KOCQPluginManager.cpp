#include "KOCQPluginManager.h"

KOCQPluginManager::KOCQPluginManager()
{

}

void KOCQPluginManager::addIconSlot(const QVariant &v)
{
    QQuickItem *parent = qobject_cast<QQuickItem*>(v.value<QObject*>());
    qDebug() << "Item dimensions:" << parent->x() << parent->y();
}
